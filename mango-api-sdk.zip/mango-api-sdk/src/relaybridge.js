import { getAccount, switchChain, sendTransaction, waitForTransactionReceipt, writeContract } from "wagmi/actions";
import { config } from "./wagmi.js";
export { MAINNET_CHAIN_IDS, NATIVE_SYMBOL, TOKEN_ADDRESSES, currencyAddress, canRelayHandle, ASSET_ONCHAIN_DECIMALS } from "./chainData.js";
import { MAINNET_CHAIN_IDS, currencyAddress } from "./chainData.js";

const DEV_FEE_WALLET = "0xf07becc2401a646fff10d10b969ef18b03582e88";
const DEV_FEE_PCT = 0.01;
export { DEV_FEE_WALLET, DEV_FEE_PCT };

const ERC20_TRANSFER_ABI = [
  { name: "transfer", type: "function", stateMutability: "nonpayable", inputs: [{ name: "to", type: "address" }, { name: "amount", type: "uint256" }], outputs: [{ type: "bool" }] },
];

/**
 * Sends the 1% protocol fee as its own visible on-chain transfer, same
 * pattern used for CCTP transfers elsewhere in this app — the fee is never
 * silently bundled into another transaction.
 */
export async function sendRelayProtocolFee({ chainKey, chainId, assetSymbol, feeBaseUnits }) {
  if (feeBaseUnits <= 0n) return null;
  await switchChain(config, { chainId });
  const currency = currencyAddress(chainKey, assetSymbol);
  let hash;
  if (currency === NATIVE_TOKEN_ADDRESS) {
    hash = await sendTransaction(config, { to: DEV_FEE_WALLET, value: feeBaseUnits, chainId });
  } else {
    hash = await writeContract(config, {
      address: currency,
      abi: ERC20_TRANSFER_ABI,
      functionName: "transfer",
      args: [DEV_FEE_WALLET, feeBaseUnits],
      chainId,
    });
  }
  await waitForTransactionReceipt(config, { hash, chainId });
  return hash;
}

// Relay Protocol — confirmed independently across three sources: Relay's own
// docs, Robinhood's own bridging documentation (which recommends Relay
// directly), and live in OKX Wallet's bridge feature. Chosen specifically
// because it's non-custodial (a solver network, not a liquidity pool we'd
// have to trust operationally) and supports genuine any-asset, any-chain
// routing — including pairs with no canonical bridge, like BNB<->ETH or
// direct L2-to-L2 transfers.
//
// IMPORTANT — read this before trusting this module:
// This is a fundamentally different trust model than CCTP, the OP Stack
// bridge, or the Arbitrum bridge. Those move funds through immutable,
// audited contracts with no discretion. Relay works via solvers who front
// liquidity on the destination chain and get repaid on the source — you are
// trusting Relay's solver network to fulfill correctly, not just contract
// math. Relay's docs state failed steps auto-refund rather than getting
// stuck, which is a meaningful safety property, but it's still a different
// category of trust than the other three integrations in this app.
//
// This module has NOT been proven live yet — it's built directly against
// Relay's own documented request/response schema (verified from two
// independent sources agreeing on the exact same shape), but "correctly
// built" and "proven in production" are different things until it's
// actually run. Test with the smallest possible real amount first.

const RELAY_QUOTE_URL = "https://api.relay.link/quote/v2";
const RELAY_STATUS_URL = "https://api.relay.link/intents/status/v3";
const NATIVE_TOKEN_ADDRESS = "0x0000000000000000000000000000000000000000";

/**
 * Fetches a Relay quote for moving `amountBaseUnits` of `fromAsset` on
 * `fromChainKey` into `toAsset` on `toChainKey`. Amount must already be in
 * base units (wei/smallest denomination) as a string, matching the asset's
 * actual decimals — this function does not do decimal conversion itself.
 */
export async function getRelayQuote({ fromChainKey, toChainKey, fromAsset, toAsset, amountBaseUnits, userAddress, recipientAddress }) {
  const body = {
    user: userAddress,
    // Real fix for a real gap: previously this always used userAddress as
    // the implicit recipient too, meaning a custom destination address
    // typed into the UI was silently ignored for every Relay-routed
    // transfer — funds always landed back in the connected wallet
    // regardless of what was entered. recipient is Relay's own documented
    // field for this exact case (their own product supports sending to a
    // different wallet, including a different chain type entirely, like
    // EVM-to-Solana). Falls back to userAddress when no override is
    // given, preserving the original behavior exactly for the common case.
    recipient: recipientAddress || userAddress,
    originChainId: MAINNET_CHAIN_IDS[fromChainKey],
    destinationChainId: MAINNET_CHAIN_IDS[toChainKey],
    originCurrency: currencyAddress(fromChainKey, fromAsset),
    destinationCurrency: currencyAddress(toChainKey, toAsset),
    amount: amountBaseUnits,
    tradeType: "EXACT_INPUT",
  };
  const res = await fetch(RELAY_QUOTE_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Relay quote failed (${res.status}): ${text || res.statusText}`);
  }
  return res.json();
}

async function pollRelayStatus(requestId, { intervalMs = 2000, timeoutMs = 10 * 60 * 1000 } = {}) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await fetch(`${RELAY_STATUS_URL}?requestId=${requestId}`);
    if (res.ok) {
      const data = await res.json();
      if (data.status === "success") return data;
      if (data.status === "failure") throw new Error("Relay reported this transfer failed — check the requestId on relay.link for details.");
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  throw new Error("Timed out waiting for Relay to confirm completion. Your deposit transaction succeeded — check status manually using the requestId before retrying.");
}

/**
 * Executes a quote obtained from getRelayQuote: signs and sends every
 * pending transaction step in order, on whichever chain each step requires,
 * then polls until Relay confirms the destination side is complete.
 */
export async function executeRelayQuote({ quote, onStep }) {
  onStep?.("build");
  let requestId = null;
  const txHashes = [];

  for (const step of quote.steps) {
    if (step.kind !== "transaction") {
      throw new Error(`Unsupported Relay step kind "${step.kind}" — only transaction steps are handled by this app.`);
    }
    requestId = requestId || step.requestId;

    for (const item of step.items) {
      if (item.status === "complete") continue;
      const { to, data, value, chainId } = item.data;

      onStep?.("deposit");
      if (chainId) await switchChain(config, { chainId });
      const hash = await sendTransaction(config, {
        to,
        data,
        value: value ? BigInt(value) : 0n,
        chainId,
      });
      txHashes.push(hash);
      onStep?.({ key: "hash-known", txHash: hash });
      await waitForTransactionReceipt(config, { hash, chainId });
    }
  }

  onStep?.("fill");
  await pollRelayStatus(requestId);

  onStep?.("done");
  return { txHashes, requestId };
}

// ASSET_ONCHAIN_DECIMALS now lives in chainData.js — re-exported at the top of this file.
